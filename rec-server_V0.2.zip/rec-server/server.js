const express = require ( 'express' );
const path = require ( 'path' );
const bodyParser = require ( 'body-parser' );
const mysql = require('mysql');


var contact = require ('./routes/contact');
var course = require ('./routes/course');
var semester = require('./routes/semester');
var index = require ('./routes/index');
var login = require ('./routes/login');
var success = require('./routes/success');
var settingsBAMA = require ('./routes/settings-bama');
var settingsPU = require('./routes/settings-pu');
var css = require('./routes/css');



var app = express();


//Setting up MySQL Connection

var database =  mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : 'root',
    database : 'recruitingplattform'
  });
  
  //Connecting to db
 database.connect(function(err){
    if (err) {
        console.error('error connecting: ' + err.stack);
       /* //Closing the connection
        db.end();*/
        return;
      }else{
        console.log('Successfully connected to db as id ' + database.threadId);
       
            }
     
  
});


//Setting the Port for the Server
var port = 3000;

//Setting up the View Engine
app.set('views', path.join(__dirname, '/views'));
app.set('view engine', 'ejs');
app.engine('html', require('ejs').renderFile);

//Setting up Static Folder for Angular -> Not in use atm, maybe later
//app.use(express.static(path.join(__dirname, 'client')));
//app.use(express.static(__dirname + '/views'));




//Setting up Body Parser Middelware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended : false}));

//Setting up the Routes
app.use('/views', css);
app.use('/success', success);
app.use('/contact', contact);
app.use('/course', course);
app.use('/login', login);
app.use('/semester', semester);
app.use('/settingsBAMA', settingsBAMA);
app.use('/settingsPU', settingsPU);
app.use('/index', index);
app.use('/', index);



//Setting up the Server to listen

//Make server accessable for other .js
module.exports ={db: database};

app.listen(port, ()=>{
    console.log('Server started! Port: '+port);

    console.log('DEBUG: Testing MySQL Connection:');
    database.query('SELECT * FROM user', (err, result)=>{
        console.log(result);
    })
});

