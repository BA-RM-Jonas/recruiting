const express = require ('express');
const router = express.Router();
const fs = require('fs');
const mysql = require ('mysql');
const bodyParser=require('body-parser');


var server = require('../server.js');
var db=server.db;

//Handle GET Request
router.get('/', (req, res, next) =>{
    console.log('GET METHOD CALLED! -- contacts');
        //Executing a query
    
      fs.readFile('./views/contact.html', null, (error, data)=>{
        if(error){
          res.writeHead(404);
          res.write('File not found!');
          res.end();
        }else{
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.write(data);
        res.end();
        }
      });
    
    });
  
 

//Handle POST Request -> this is where the magic happens
    router.post('/', (req, res, next)=>{
    
      console.log('POST METHOD CALLED! -- contacts');
        let anrede = req.body.anrede;
        let vorname = req.body.vorname;
        let name = req.body.name;
        let geburtsdatum = req.body.geburtsdatum;
        let strasse = req.body.strasse;
        let hausnummer = req.body.hausnummer;
        let plz = req.body.plz;
        let ort = req.body.ort;
        let land = req.body.land;
        let telefonnr = req.body.telefonnr;
        let email = req.body.email;
        
        let sql = 'INSERT INTO user (anrede, vorname, name, geburtsdatum, strasse, hausnummer, plz, ort, land, telefonnr, e-mail) VALUES (/"'+anrede+'/",/"'+vorname+'/",/"'+name+'/",/"'+geburtsdatum+'/",/"'+strasse+'/",/"'+hausnummer+'/", '+plz+',/"'+ort+'/",/"'+land+'/",/"'+telefonnr+'/",/"'+email+'/")';
        
       console.log('Trying to query SQL: '+sql);
    
        let query = db.query(sql, (err, results) => {
            if (err){
                console.error('error connecting: ' + err.stack);
               /* //Closing the connection
                db.end();*/
            } else{
            console.log('Values have been added to db ->');
            console.log(results);
            //res.writeHead(200, {'Content-Type': 'text/plain'});
           // res.write('Done!');
           // res.end();
            res.redirect('/success');
            }
          });
        
    
    });

 module.exports = router;