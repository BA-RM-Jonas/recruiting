const express = require ('express');
const router = express.Router();
const fs = require('fs');
const mysql = require ('mysql');
const bodyParser=require('body-parser');


var server = require('../server.js');
var db=server.db;

//Handle GET Request
router.get('/', (req, res, next) =>{
    console.log('GET METHOD CALLED!');
        //Executing a query
    db.query('SELECT * from test', (err, results)=> {
      if (err){
          console.error('error connecting: ' + err.stack);
        /*  //Closing the connection
          db.end();*/
      } else{
      fs.readFile('./views/course.html', null, (error, data)=>{
        if(error){
          res.writeHead(404);
          res.write('File not found!');
          res.end();
        }else{
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.write(data);
        res.end();
        }
      });
    }
    });
  
    });

//Handle POST Request -> this is where the magic happens
    router.post('/', (req, res, next)=>{
    
      console.log('POST METHOD CALLED!');
        let myNumber = req.body.number;
        let sql = 'INSERT INTO test VALUES (?)';
        
       // var input;
       // console.log('myNumber ='+myNumber);
       // console.log('input='+input);
    
        //@TODO Validation of recieved Data
    
        //console.log('Got a Post request' + login);
    
        let query = db.query(sql, myNumber, (err, results) => {
            if (err){
                console.error('error connecting: ' + err.stack);
               /* //Closing the connection
                db.end();*/
            } else{
            console.log('myNumber has been added to db ->'+ myNumber);
            console.log(results);
            //res.writeHead(200, {'Content-Type': 'text/plain'});
           // res.write('Done!');
           // res.end();
            res.redirect('/success');
            }
          });
        
    
    });

 module.exports = router;