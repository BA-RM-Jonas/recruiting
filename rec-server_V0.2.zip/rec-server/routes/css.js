const express = require ('express');
const router = express.Router();
const fs = require('fs');
const mysql = require ('mysql');
const bodyParser=require('body-parser');


//Handle GET Request
router.get('/style.css', (req, res, next) =>{
    console.log('GET METHOD CALLED! -- css');
        //Executing a query
    
      fs.readFile('./views/css/style.css', null, (error, data)=>{
        if(error){
          res.writeHead(404);
          res.write('File not found!');
          res.end();
        }else{
        res.writeHead(200, {'Content-Type': 'text/css'});
        res.write(data);
        res.end();
        }
      });
    
    });

    module.exports = router;