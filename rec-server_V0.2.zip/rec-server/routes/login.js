const express = require ('express');
const router = express.Router();
const fs = require('fs');
const mysql = require ('mysql');
const bodyParser=require('body-parser');


var server = require('../server.js');
var db=server.db;

    

router.get('/', (req, res, next) =>{
  console.log('GET METHOD CALLED! -- login');
    fs.readFile('./views/login.html', null, (error, data)=>{
        if(error){
          res.writeHead(404);
          res.write('File not found!');
        }else{
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.write(data);
        res.end();
        }
      });
    
});

router.post('/', (req, res, next) =>{

  console.log('POST METHOD CALLED on /login!');
  let username= req.body.username;
  let password= req.body.password;
  console.log('LOGIN REQUEST with user: '+username+', password: '+password);

  let sql='SELECT password, type FROM ba-ma WHERE username = ?';

  let query = db.query(sql, username, (err, result)=>{

    if (err){
      console.error('error connecting: ' + err.stack);
  } else{
    let dbPassword = result.body.password;

    if(password==dbPassword){      
        res.redirect('/bama');
    } else {
    
    sql='SELECT password, type FROM pu WHERE username = ?';
    query= db.query.apply(sql, username, (err, result)=>{

      if (err){
        console.error('error connecting: ' + err.stack);
    }else{
      let dbPassword = result.body.password;
  
      if(password==dbPassword){      
          res.redirect('/pu');
      } else{
        console.log('User Password combination incorrect');
      }
    }
  });
}
}
  });

});

module.exports = router;