const express = require ('express');
const router = express.Router();
const mysql = require ('mysql');
const fs = require('fs');
const bodyParser=require('body-parser');

var server = require('../server.js');
var db=server.db;

//Handle GET Request
router.get('/', (req, res, next) =>{
  console.log('GET METHOD CALLED! --index');
      //Executing a query
  db.query('SELECT * from test', (err, results)=> {
    if (err){
        console.error('error connecting: ' + err.stack);
      /*  //Closing the connection
        db.end();*/
    } else{
    fs.readFile('./views/index.html', null, (error, data)=>{
      if(error){
        res.writeHead(404);
        res.write('File not found!');
        res.end();
      }else{
      res.writeHead(200, {'Content-Type': 'text/html'});
      res.write(data);
      res.end();
      }
    });
  }
  });

  });
  
  

//Handle GET/data Request
//Handle GET Request
router.get('/data', (req, res, next) =>{
  console.log('GET DATA METHOD CALLED!');
      //Executing a query
  db.query('SELECT * from test', (err, results)=> {
    if (err){
        console.error('error connecting: ' + err.stack);
        res.writeHead(404);
        res.write('File not found!');
        res.end();
      /*  //Closing the connection
        db.end();*/
    } else{
    
      res.writeHead(200, {'Content-Type': 'text/plain'});
      for(var i=0; i<results.length; i++){
        res.write(i+': '+results[i].test +'\n');
      }      
      res.end();
      }
  }
  );

  });
  

//Handle POST Request -> this is where the magic happens
router.post('/', (req, res, next)=>{

  console.log('POST METHOD CALLED!');
    let myNumber = req.body.number;
    let sql = 'INSERT INTO test VALUES (?)';
    
   // var input;
   // console.log('myNumber ='+myNumber);
   // console.log('input='+input);

    //@TODO Validation of recieved Data

    //console.log('Got a Post request' + login);

    let query = db.query(sql, myNumber, (err, results) => {
        if (err){
            console.error('error connecting: ' + err.stack);
           /* //Closing the connection
            db.end();*/
        } else{
        console.log('myNumber has been added to db ->'+ myNumber);
        console.log(results);
        //res.writeHead(200, {'Content-Type': 'text/plain'});
       // res.write('Done!');
       // res.end();
        res.redirect('/success');
        }
      });
    

});

//router.post('/redirect', function(req, res, next){
//  console.log('POST METHOD CALLED on /redirect!');
//  res.redirect('/login');
//});

//router.submit('/', funciton(req, res, next){
 // res.write('Got a Submit request');
//});

module.exports = router;