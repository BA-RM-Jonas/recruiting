const express = require ('express');
const router = express.Router();
const fs = require('fs');

router.get('/success', (req, res, next) =>{
    fs.readFile('./views/success.html', null, (error, data) =>{
        if(error){
          res.writeHead(404);
          res.write('File not found!');
        }else{
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.write(data);
        res.end();
        }
      });
    
});

module.exports = router;