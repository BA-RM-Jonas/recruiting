const express = require ('express');
const router = express.Router();
const fs = require('fs');
const mysql = require ('mysql');
const bodyParser=require('body-parser');


var server = require('../server.js');
var db=server.db;

    

router.get('/login', (req, res, next) =>{
    fs.readFile('./views/login.html', null, (error, data)=>{
        if(error){
          res.writeHead(404);
          res.write('File not found!');
        }else{
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.write(data);
        res.end();
        }
      });
    
});

router.post('/login', (req, res, next) =>{

  console.log('POST METHOD CALLED on /login!');
  let username= req.body.username;
  let password= req.body.password;
  console.log('LOGIN REQUEST with user: '+username+', password: '+password);

  let sql='SELECT password, type FROM user WHERE username = ?';

  let query = db.query(sql, username, (err, result)=>{

    if (err){
      console.error('error connecting: ' + err.stack);
  } else{
    let dbPassword = result.body.password;
    let dbType = result.body.type;

    if(password==dbPassword){
      if(type==1){
        res.redirect('/bama');
      }else if(type==2){
        res.redirect('/pu');
      }
    }}
  })
  
});

module.exports = router;