-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server Version:               5.7.17-log - MySQL Community Server (GPL)
-- Server Betriebssystem:        Win64
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Exportiere Datenbank Struktur für recruitingplattform
CREATE DATABASE IF NOT EXISTS `recruitingplattform` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `recruitingplattform`;

-- Exportiere Struktur von Tabelle recruitingplattform.account
CREATE TABLE IF NOT EXISTS `account` (
  `Account_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Benutzername` varchar(45) NOT NULL,
  `Passwort` varchar(45) NOT NULL,
  `Vorname` varchar(45) NOT NULL,
  `Name` varchar(45) NOT NULL,
  `Geburtsdatum` date NOT NULL,
  `EMail` varchar(45) NOT NULL,
  `Telefonnr` varchar(50) NOT NULL,
  `Strasse` varchar(45) NOT NULL,
  `Hausnummer` varchar(50) NOT NULL,
  `Ort` varchar(45) NOT NULL,
  `PLZ` varchar(50) NOT NULL,
  PRIMARY KEY (`Account_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Exportiere Daten aus Tabelle recruitingplattform.account: ~2 rows (ungefähr)
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` (`Account_ID`, `Benutzername`, `Passwort`, `Vorname`, `Name`, `Geburtsdatum`, `EMail`, `Telefonnr`, `Strasse`, `Hausnummer`, `Ort`, `PLZ`) VALUES
	(1, 'JanLietz', '1234', 'Jan', 'Lietz', '2017-08-27', 'jan.lietz@ba-rm.de', '1233456789', 'Eder', '9', 'Dreieich', '63303'),
	(2, 'LukasLandmann', '5678', 'Lukas', 'Landmann', '2017-08-27', 'lukas.landmann@ba-rm.de', '987654321', 'Siedler', '17', 'Dietzenbach', '63128'),
	(3, 'DanielWolfsberger', '9012', 'Daniel', 'Wolfsberger', '2017-09-04', 'daniel.wolfsberger@ba-rm.de', '0987665432', 'Haupt', '23', 'Rödermark', '63000');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;

-- Exportiere Struktur von Tabelle recruitingplattform.admin
CREATE TABLE IF NOT EXISTS `admin` (
  `Admin_ID` int(11) NOT NULL AUTO_INCREMENT,
  `BA_MA_ID` int(11) NOT NULL DEFAULT '0',
  `Rechte` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Admin_ID`),
  KEY `BA-MA-ID` (`BA_MA_ID`),
  CONSTRAINT `BA_MA_ID` FOREIGN KEY (`BA_MA_ID`) REFERENCES `ba_ma` (`BA_MA_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Exportiere Daten aus Tabelle recruitingplattform.admin: ~0 rows (ungefähr)
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`Admin_ID`, `BA_MA_ID`, `Rechte`) VALUES
	(1, 1, 1);
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;

-- Exportiere Struktur von Tabelle recruitingplattform.ansprechpartner
CREATE TABLE IF NOT EXISTS `ansprechpartner` (
  `Ansprechpartner_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Account_ID` int(11) NOT NULL,
  `PU_ID` int(11) NOT NULL,
  PRIMARY KEY (`Ansprechpartner_ID`),
  KEY `Account-ID` (`Account_ID`),
  KEY `PU-ID` (`PU_ID`),
  CONSTRAINT `Account_ID` FOREIGN KEY (`Account_ID`) REFERENCES `account` (`Account_ID`),
  CONSTRAINT `PU_ID` FOREIGN KEY (`PU_ID`) REFERENCES `pu` (`PU_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Exportiere Daten aus Tabelle recruitingplattform.ansprechpartner: ~0 rows (ungefähr)
/*!40000 ALTER TABLE `ansprechpartner` DISABLE KEYS */;
INSERT INTO `ansprechpartner` (`Ansprechpartner_ID`, `Account_ID`, `PU_ID`) VALUES
	(1, 2, 1);
/*!40000 ALTER TABLE `ansprechpartner` ENABLE KEYS */;

-- Exportiere Struktur von Tabelle recruitingplattform.ba_ma
CREATE TABLE IF NOT EXISTS `ba_ma` (
  `BA_MA_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Account_ID` int(11) NOT NULL,
  PRIMARY KEY (`BA_MA_ID`),
  KEY `Account-ID2` (`Account_ID`),
  CONSTRAINT `Account_ID2` FOREIGN KEY (`Account_ID`) REFERENCES `account` (`Account_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Exportiere Daten aus Tabelle recruitingplattform.ba_ma: ~0 rows (ungefähr)
/*!40000 ALTER TABLE `ba_ma` DISABLE KEYS */;
INSERT INTO `ba_ma` (`BA_MA_ID`, `Account_ID`) VALUES
	(1, 1);
/*!40000 ALTER TABLE `ba_ma` ENABLE KEYS */;

-- Exportiere Struktur von Tabelle recruitingplattform.bewerbungsanschreiben
CREATE TABLE IF NOT EXISTS `bewerbungsanschreiben` (
  `Bewerbungsanschreiben_ID` int(11) NOT NULL AUTO_INCREMENT,
  `hinzugefuegt` tinyint(2) DEFAULT NULL,
  PRIMARY KEY (`Bewerbungsanschreiben_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Exportiere Daten aus Tabelle recruitingplattform.bewerbungsanschreiben: ~0 rows (ungefähr)
/*!40000 ALTER TABLE `bewerbungsanschreiben` DISABLE KEYS */;
INSERT INTO `bewerbungsanschreiben` (`Bewerbungsanschreiben_ID`, `hinzugefuegt`) VALUES
	(1, 1),
	(2, 0);
/*!40000 ALTER TABLE `bewerbungsanschreiben` ENABLE KEYS */;

-- Exportiere Struktur von Tabelle recruitingplattform.dokument
CREATE TABLE IF NOT EXISTS `dokument` (
  `Dokument_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Hochgeladen` tinyint(2) NOT NULL,
  `Zertifizierungen_ID` int(11) NOT NULL,
  `Lebenslauf_ID` int(11) NOT NULL,
  `Bewerbungsanschreiben_ID` int(11) NOT NULL,
  PRIMARY KEY (`Dokument_ID`),
  KEY `Zertifizierungen-ID` (`Zertifizierungen_ID`),
  KEY `Lebenslauf-ID` (`Lebenslauf_ID`),
  KEY `Bewerbungsanschreiben-ID` (`Bewerbungsanschreiben_ID`),
  CONSTRAINT `Bewerbungsanschreiben_ID` FOREIGN KEY (`Bewerbungsanschreiben_ID`) REFERENCES `bewerbungsanschreiben` (`Bewerbungsanschreiben_ID`),
  CONSTRAINT `Lebenslauf_ID` FOREIGN KEY (`Lebenslauf_ID`) REFERENCES `lebenslauf` (`Lebenslauf_ID`),
  CONSTRAINT `Zertifizierungen_ID` FOREIGN KEY (`Zertifizierungen_ID`) REFERENCES `zertifizierungen` (`Zertifizierungen_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Exportiere Daten aus Tabelle recruitingplattform.dokument: ~2 rows (ungefähr)
/*!40000 ALTER TABLE `dokument` DISABLE KEYS */;
INSERT INTO `dokument` (`Dokument_ID`, `Hochgeladen`, `Zertifizierungen_ID`, `Lebenslauf_ID`, `Bewerbungsanschreiben_ID`) VALUES
	(1, 1, 1, 1, 1),
	(2, 0, 2, 2, 2);
/*!40000 ALTER TABLE `dokument` ENABLE KEYS */;

-- Exportiere Struktur von Tabelle recruitingplattform.lebenslauf
CREATE TABLE IF NOT EXISTS `lebenslauf` (
  `Lebenslauf_ID` int(11) NOT NULL AUTO_INCREMENT,
  `hinzugefuegt` tinyint(2) DEFAULT NULL,
  PRIMARY KEY (`Lebenslauf_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Exportiere Daten aus Tabelle recruitingplattform.lebenslauf: ~2 rows (ungefähr)
/*!40000 ALTER TABLE `lebenslauf` DISABLE KEYS */;
INSERT INTO `lebenslauf` (`Lebenslauf_ID`, `hinzugefuegt`) VALUES
	(1, 1),
	(2, 0);
/*!40000 ALTER TABLE `lebenslauf` ENABLE KEYS */;

-- Exportiere Struktur von Tabelle recruitingplattform.pu
CREATE TABLE IF NOT EXISTS `pu` (
  `PU_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Firmenname` varchar(50) DEFAULT NULL,
  `Account_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`PU_ID`),
  KEY `Account-ID3` (`Account_ID`),
  CONSTRAINT `Account_ID3` FOREIGN KEY (`Account_ID`) REFERENCES `account` (`Account_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Exportiere Daten aus Tabelle recruitingplattform.pu: ~2 rows (ungefähr)
/*!40000 ALTER TABLE `pu` DISABLE KEYS */;
INSERT INTO `pu` (`PU_ID`, `Firmenname`, `Account_ID`) VALUES
	(1, 'Systel', 2),
	(2, 'Netz', 2);
/*!40000 ALTER TABLE `pu` ENABLE KEYS */;

-- Exportiere Struktur von Tabelle recruitingplattform.semester
CREATE TABLE IF NOT EXISTS `semester` (
  `Semester_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Semesterbeginn` date NOT NULL,
  PRIMARY KEY (`Semester_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Exportiere Daten aus Tabelle recruitingplattform.semester: ~0 rows (ungefähr)
/*!40000 ALTER TABLE `semester` DISABLE KEYS */;
INSERT INTO `semester` (`Semester_ID`, `Semesterbeginn`) VALUES
	(1, '2017-08-23'),
	(2, '2017-09-04'),
	(3, '2017-10-04');
/*!40000 ALTER TABLE `semester` ENABLE KEYS */;

-- Exportiere Struktur von Tabelle recruitingplattform.studiengang
CREATE TABLE IF NOT EXISTS `studiengang` (
  `Studiengang_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Studienfach` varchar(45) NOT NULL,
  PRIMARY KEY (`Studiengang_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Exportiere Daten aus Tabelle recruitingplattform.studiengang: ~0 rows (ungefähr)
/*!40000 ALTER TABLE `studiengang` DISABLE KEYS */;
INSERT INTO `studiengang` (`Studiengang_ID`, `Studienfach`) VALUES
	(1, 'WI'),
	(2, 'BWL');
/*!40000 ALTER TABLE `studiengang` ENABLE KEYS */;

-- Exportiere Struktur von Tabelle recruitingplattform.user
CREATE TABLE IF NOT EXISTS `user` (
  `User_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Anrede` char(4) NOT NULL,
  `Vorname` varchar(45) NOT NULL,
  `Name` varchar(45) NOT NULL,
  `Geburtsdatum` date NOT NULL,
  `Strasse` varchar(45) NOT NULL,
  `Hausnummer` varchar(50) NOT NULL,
  `PLZ` varchar(50) NOT NULL,
  `Ort` varchar(45) NOT NULL,
  `Land` varchar(50) NOT NULL,
  `Telefonnr` varchar(50) NOT NULL,
  `EMail` varchar(45) NOT NULL,
  `Studiengang_ID` int(11) NOT NULL,
  `Semester_ID` int(11) NOT NULL,
  `Dokument_ID` int(11) NOT NULL,
  `Workflow_ID` int(11) NOT NULL,
  `PU_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`User_ID`),
  KEY `Workflow-ID` (`Workflow_ID`),
  KEY `Dokument-ID` (`Dokument_ID`),
  KEY `Semester-ID` (`Semester_ID`),
  KEY `Studiengang-ID` (`Studiengang_ID`),
  KEY `PU_ID2` (`PU_ID`),
  CONSTRAINT `Dokument_ID` FOREIGN KEY (`Dokument_ID`) REFERENCES `dokument` (`Dokument_ID`),
  CONSTRAINT `PU_ID2` FOREIGN KEY (`PU_ID`) REFERENCES `pu` (`PU_ID`),
  CONSTRAINT `Semester_ID` FOREIGN KEY (`Semester_ID`) REFERENCES `semester` (`Semester_ID`),
  CONSTRAINT `Studiengang_ID` FOREIGN KEY (`Studiengang_ID`) REFERENCES `studiengang` (`Studiengang_ID`),
  CONSTRAINT `Workflow_ID` FOREIGN KEY (`Workflow_ID`) REFERENCES `workflow` (`Workflow_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Exportiere Daten aus Tabelle recruitingplattform.user: ~2 rows (ungefähr)
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`User_ID`, `Anrede`, `Vorname`, `Name`, `Geburtsdatum`, `Strasse`, `Hausnummer`, `PLZ`, `Ort`, `Land`, `Telefonnr`, `EMail`, `Studiengang_ID`, `Semester_ID`, `Dokument_ID`, `Workflow_ID`, `PU_ID`) VALUES
	(1, 'Herr', 'Niclas', 'Raimund', '2017-08-27', 'Schopenhauer', '54', '63303', 'Dreieich', 'Deutschland', '135798642', 'niclas.raimund@ba-rm.de', 1, 1, 1, 1, 1),
	(2, 'Herr', 'Ron', 'Reiser', '1991-04-01', 'Schoppe', '30', '63303', 'Dreieich', 'Deutschland', '0987654321', 'ron.reiser@ba-rm.de', 1, 1, 1, 1, 1),
	(3, 'a', 'b', 'c', '1991-04-01', 'e', '2', '456457', 'land', 'deutsch', '12345657', 'TestMail', 1, 1, 1, 1, 1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

-- Exportiere Struktur von Tabelle recruitingplattform.workflow
CREATE TABLE IF NOT EXISTS `workflow` (
  `Workflow_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Next` tinyint(4) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Workflow_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Exportiere Daten aus Tabelle recruitingplattform.workflow: ~4 rows (ungefähr)
/*!40000 ALTER TABLE `workflow` DISABLE KEYS */;
INSERT INTO `workflow` (`Workflow_ID`, `Next`, `Status`) VALUES
	(1, 2, 'Eingegangen'),
	(2, 3, 'Bearbeitet'),
	(3, 4, 'Angenommen'),
	(4, 5, 'Abgelehnt');
/*!40000 ALTER TABLE `workflow` ENABLE KEYS */;

-- Exportiere Struktur von Tabelle recruitingplattform.zertifizierungen
CREATE TABLE IF NOT EXISTS `zertifizierungen` (
  `Zertifizierungen_ID` int(11) NOT NULL AUTO_INCREMENT,
  `hinzugefuegt` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`Zertifizierungen_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Exportiere Daten aus Tabelle recruitingplattform.zertifizierungen: ~0 rows (ungefähr)
/*!40000 ALTER TABLE `zertifizierungen` DISABLE KEYS */;
INSERT INTO `zertifizierungen` (`Zertifizierungen_ID`, `hinzugefuegt`) VALUES
	(1, 0),
	(2, 1);
/*!40000 ALTER TABLE `zertifizierungen` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
