/* Partnerunternehmen_Listenausgabe */

Select pu.`PU_ID`, pu.Firmenname, account.Name, account.`EMail`, account.Telefonnr 
FROM pu
LEFT Join account ON pu.`Account_ID` = account.`Account_ID`;