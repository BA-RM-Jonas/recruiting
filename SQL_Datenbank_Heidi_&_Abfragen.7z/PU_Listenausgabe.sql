/* Partnerunternehmen_Listenausgabe */

Select pu.`PU-ID`, pu.Firmenname, account.Name, account.`E-Mail`, account.Telefonnr 
FROM pu
LEFT Join account ON pu.`Account-ID` = account.`Account-ID`;