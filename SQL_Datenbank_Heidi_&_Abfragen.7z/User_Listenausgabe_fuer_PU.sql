/* User_Listenausgabe_fuer_PU */

SELECT user.`User_ID`, user.Name, user.Vorname, studiengang.Studienfach, user.Geburtsdatum, user.`EMail`, user.Telefonnr
FROM pu
LEFT JOIN ( user 
LEFT JOIN studiengang
ON user.`Studiengang_ID` = studiengang.`Studiengang_ID`
)
ON user.`PU_ID` = pu.`PU_ID`

WHERE pu.`PU_ID` = 1

 ;