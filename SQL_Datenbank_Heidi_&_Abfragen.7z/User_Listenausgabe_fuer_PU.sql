/* User_Listenausgabe_fuer_PU */

SELECT user.`User-ID`, user.Name, user.Vorname, studiengang.Studienfach, user.Geburtsdatum, user.`E-Mail`, user.Telefonnr
FROM pu
LEFT JOIN ( user 
LEFT JOIN studiengang
ON user.`Studiengang-ID` = studiengang.`Studiengang-ID`
)
ON user.`PU-ID` = pu.`PU-ID`

/* Automatisierung der Studentenansicht nach Partnerunternehmen nach bisherigen kenntnisstand nicht möglich! */

WHERE pu.`PU-ID` = 1

 ;