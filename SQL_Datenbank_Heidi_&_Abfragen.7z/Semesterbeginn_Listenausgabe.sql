/* Semesterbeginn_Listenausgabe */

SELECT semester.Semesterbeginn
FROM Semester;