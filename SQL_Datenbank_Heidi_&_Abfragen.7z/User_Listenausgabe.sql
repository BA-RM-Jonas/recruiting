/* User_Listenausgabe */

SELECT user.`User_ID`, user.Name, user.Vorname, studiengang.Studienfach, user.Geburtsdatum, user.`EMail`, user.Telefonnr
FROM User
LEFT JOIN Studiengang ON user.`Studiengang_ID` = studiengang.`Studiengang_ID`;