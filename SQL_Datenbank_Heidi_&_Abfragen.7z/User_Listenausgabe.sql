/* User_Listenausgabe */

SELECT user.`User-ID`, user.Name, user.Vorname, studiengang.Studienfach, user.Geburtsdatum, user.`E-Mail`, user.Telefonnr
FROM User
LEFT JOIN Studiengang ON user.`Studiengang-ID` = studiengang.`Studiengang-ID`;