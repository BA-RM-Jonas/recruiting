/* Studiengang_Listenausgabe */

SELECT studiengang.Studienfach
FROM studiengang ;